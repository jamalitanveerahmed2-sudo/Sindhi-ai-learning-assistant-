# Sindhi AI Learning Assistant

Responsive browser MVP for Sindhi, Urdu and English learners.

## Included
- Home screen and beginner learning path
- Offline tutor guide for common beginner topics
- Starter phrasebook lookup: Sindhi, Roman Sindhi, Urdu and English
- Sindhi alphabet and everyday vocabulary examples
- Kids learning question
- Sindh history, poetry and cultural overview

## Run
Open `index.html` in a modern browser.

## Enable GitHub Pages
In the repository, open Settings → Pages. Choose Deploy from a branch, select `main` and `/ (root)`, then Save.

## Honest limitations
- The tutor is an offline guide, not a live generative AI connection.
- Translation is a small phrasebook, not full machine translation.
- A production AI tutor requires a secure backend and server-side API key. Never put a private API key in browser or mobile app code.
- This is a browser MVP, not an Android APK.

Photo editing, gallery and voice chat are intentionally excluded.
