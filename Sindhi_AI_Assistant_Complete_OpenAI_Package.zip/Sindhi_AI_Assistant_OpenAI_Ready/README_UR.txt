سنڌي AI اسسٽنٽ — مڪمل OpenAI چيٽ پيڪيج
==========================================

هن پيڪيج ۾ شامل آهي:
• موبائل تي هلندڙ سنڌي AI Assistant ويب ايپ
• حقيقي OpenAI جوابن لاءِ Node.js سرور
• محفوظ API Key سيٽنگ (Key ويب پيج يا HTML ۾ نه رکبي)
• Render تي Deploy ڪرڻ لاءِ render.yaml

اهم ڳالهه: API Key کي سڌو موبائل ايپ/HTML ۾ رکڻ محفوظ ناهي. OpenAI جي هدايت موجب Key سرور جي Environment Variable ۾ رکڻ گهرجي. تنهنڪري توهان جو آخري Key وارو قدم Render جي سرور سيٽنگ ۾ ٿيندو، ايپ جي چيٽ باڪس ۾ نه.

حصو 1 — ايپ کي آن لائن ڪرڻ
---------------------------
1. ZIP فائل Extract ڪريو.
2. اندر موجود Sindhi_AI_Assistant_OpenAI_Ready فولڊر کوليو.
3. GitHub.com تي Sign in ڪريو ۽ New repository ٺاهيو. نالو رکو: sindhi-ai-assistant
4. فولڊر جا سڀئي اندروني فائيل GitHub repository ۾ Upload files ذريعي اپلوڊ ڪريو. خاص طور server.js، package.json، render.yaml ۽ public فولڊر لازمي آهن.
5. Render.com تي Sign in ڪريو.
6. Dashboard مان New + دٻايو، پوءِ Blueprint چونڊيو.
7. پنهنجي GitHub اڪائونٽ کي Connect ڪريو ۽ sindhi-ai-assistant repository چونڊيو.
8. Render کي render.yaml پڙهڻ ڏيو ۽ Apply/Deploy ڪريو.

حصو 2 — توهان جو آخري Key وارو ڪم
---------------------------------
1. Render ۾ پنهنجي سروس sindhi-ai-assistant کوليو.
2. Environment ٽيب کوليو.
3. Add Environment Variable چونڊيو.
4. Key ۾ هي نالو لکو: OPENAI_API_KEY
5. Value ۾ پنهنجي OpenAI API Key پيسٽ ڪريو.
6. Save Changes ڪريو. Render سروس کي ٻيهر Deploy ڪندو.
7. Deploy مڪمل ٿيڻ تي Render توهان کي سروس جو URL ڏيندو. اهو URL کوليو؛ توهان جي چيٽ ايپ کلي ويندي.

بس، پوءِ چيٽ باڪس ۾ سوال لکو ۽ Send دٻايو. AI جواب سرور وسيلي ايندو.

ضروري حفاظت
------------
• API Key مون ڏانهن چيٽ ۾ نه موڪليو.
• API Key کي public GitHub فائيل، HTML يا JavaScript ۾ هرگز نه وجهو.
• ChatGPT جي سبسڪرپشن ۽ API بلنگ الڳ آهن؛ API استعمال لاءِ Platform تي بلنگ/ڪريڊٽ فعال هجڻ ضروري ٿي سگهي ٿو.
• جيڪڏهن Key اڳ ڪنهن سان شيئر ڪئي هجي ته نئين Key ٺاهيو.

مقامي ٽيسٽ (اختياري)
--------------------
Node.js 20 يا نئون انسٽال ڪريو. Terminal ۾ هن فولڊر اندر npm install هلائي، .env.example جي ڪاپي .env نالي ٺاهيو، ان ۾ OPENAI_API_KEY ڀريو، پوءِ npm start هلايو. Browser ۾ http://localhost:3000 کوليو.

مسئلو حل ڪرڻ
------------
• 503 يا Key وارو پيغام: Render جي Environment ۾ OPENAI_API_KEY چيڪ ڪريو.
• API/Model error: API Platform تي بلنگ ۽ OPENAI_MODEL جي دستيابي چيڪ ڪريو.
• صفحو نه کلي: Render جي Events/Logs ۾ Deploy مڪمل ٿيڻ جي تصديق ڪريو.

هي پيڪيج ويب ايپ آهي، APK نه. Android تي Render URL کولڻ کان پوءِ Chrome جي menu مان Add to Home screen ڪري سگهو ٿا. الڳ APK ٺاهڻ لاءِ Android build جي ضرورت پوندي.
