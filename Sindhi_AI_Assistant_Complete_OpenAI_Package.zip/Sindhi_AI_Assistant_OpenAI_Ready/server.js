import express from 'express';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-4.1-mini';

app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

const chatLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'توهان تمام گهڻا پيغام موڪليا آهن. مهرباني ڪري هڪ منٽ کان پوءِ ٻيهر ڪوشش ڪريو.' }
});

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Sindhi AI Assistant' }));

app.post('/chat', chatLimiter, async (req, res) => {
  if (!API_KEY) {
    return res.status(503).json({ error: 'سرور تي OpenAI API Key اڃا شامل ناهي. منتظم کي Render جي Environment سيٽنگ ۾ OPENAI_API_KEY شامل ڪرڻو پوندو.' });
  }

  const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
  const safeMessages = messages
    .filter(m => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string')
    .slice(-20)
    .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));

  if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== 'user') {
    return res.status(400).json({ error: 'مهرباني ڪري پهرين پنهنجو سوال لکو.' });
  }

  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: MODEL,
        instructions: 'You are Sindhi AI Learning Assistant, a friendly, accurate educational assistant. Reply in the same language and script the user uses: Sindhi in Arabic-based Sindhi script, Urdu in Urdu script, Roman Sindhi in Roman Sindhi, and English in English. Do not switch to Hindi unless explicitly requested. Explain clearly and respectfully. If uncertain, say so.',
        input: safeMessages.map(m => ({ role: m.role, content: m.content }))
      }),
      signal: AbortSignal.timeout(60000)
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error('OpenAI API error:', data?.error?.message || response.status);
      return res.status(502).json({ error: 'AI سروس جواب نٿي ڏئي سگهي. API Key، بلنگ ۽ ماڊل سيٽنگ چيڪ ڪريو.' });
    }

    const answer = data.output_text || (data.output || [])
      .filter(item => item.type === 'message')
      .flatMap(item => item.content || [])
      .filter(part => part.type === 'output_text')
      .map(part => part.text)
      .join('\n');

    if (!answer) return res.status(502).json({ error: 'AI طرفان خالي جواب مليو. ٻيهر ڪوشش ڪريو.' });
    res.json({ reply: answer });
  } catch (error) {
    console.error('Chat request failed:', error?.message || error);
    res.status(500).json({ error: 'نيٽ ورڪ يا سرور ۾ مسئلو ٿيو. مهرباني ڪري ٻيهر ڪوشش ڪريو.' });
  }
});

app.listen(PORT, () => console.log(`Sindhi AI Assistant listening on ${PORT}; model=${MODEL}; keyConfigured=${Boolean(API_KEY)}`));
