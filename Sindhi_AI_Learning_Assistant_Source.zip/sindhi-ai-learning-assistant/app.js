const $ = (id) => document.getElementById(id);
const messages = $("messages");
let history = [];
let activeView = "chat";

function addMessage(role, text, extraClass="") {
  const row = document.createElement("div");
  row.className = `message ${role} ${extraClass}`;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "You" : "س";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.append(avatar, bubble);
  messages.appendChild(row);
  row.scrollIntoView({behavior:"smooth", block:"end"});
  return bubble;
}
function showChat() {
  activeView = "chat";
  $("chatView").classList.remove("hidden");
  $("toolView").classList.add("hidden");
  $("composerArea").classList.remove("hidden");
  $("pageTitle").textContent = "AI Tutor";
  document.querySelectorAll(".side-item").forEach(b=>b.classList.toggle("active",b.dataset.view==="chat"));
}
function newChat() {
  history = [];
  messages.innerHTML = "";
  $("welcome").classList.remove("hidden");
  showChat();
}
async function send(text) {
  text = (text || $("promptInput").value).trim();
  if (!text) return;
  $("promptInput").value = "";
  $("welcome").classList.add("hidden");
  addMessage("user", text);
  history.push({role:"user", content:text});
  const pending = addMessage("assistant", "Thinking…", "typing");
  const cfg = window.APP_CONFIG || {};
  if (!window.supabase || !cfg.SUPABASE_URL || cfg.SUPABASE_URL.includes("YOUR-PROJECT") || !cfg.SUPABASE_ANON_KEY || cfg.SUPABASE_ANON_KEY.includes("YOUR_")) {
    pending.textContent = "Setup needed: connect the secure Supabase Edge Function first. Your Gemini key should be stored as a Supabase secret, never in the app.";
    return;
  }
  try {
    const client = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
    const {data, error} = await client.functions.invoke("chat", {
      body: {messages: history, language: $("language").value}
    });
    if (error) throw error;
    const answer = data?.reply || "I couldn't create a reply. Please try again.";
    pending.textContent = answer;
    pending.parentElement.classList.remove("typing");
    history.push({role:"assistant", content:answer});
  } catch (err) {
    pending.textContent = "Connection problem: " + (err.message || "Please check your internet and AI setup.");
    pending.parentElement.classList.remove("typing");
  }
}
$("sendBtn").addEventListener("click", ()=>send());
$("promptInput").addEventListener("keydown", e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}});
$("promptInput").addEventListener("input", e=>{e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,130)+"px";});
$("newChat").addEventListener("click",newChat);
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>send(b.dataset.prompt)));
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
document.querySelectorAll(".side-item").forEach(b=>b.addEventListener("click",()=>{
  const view=b.dataset.view;
  if(view==="chat"){showChat();$("sidebar").classList.remove("open");return;}
  activeView=view; $("chatView").classList.add("hidden");$("composerArea").classList.add("hidden");$("toolView").classList.remove("hidden");
  document.querySelectorAll(".side-item").forEach(x=>x.classList.toggle("active",x===b));
  const data={
    vocabulary:["▤","Vocabulary Studio","Build your Sindhi, Urdu and English word bank.","Ask the AI Tutor: “Teach me 10 useful Sindhi words with pronunciation and example sentences.”"],
    quiz:["◈","Quick Quiz","A small challenge makes learning stick.","Go to AI Tutor and ask: “Create a 5-question Sindhi vocabulary quiz. Ask one question at a time and check my answers.”"],
    grammar:["文","Grammar Guide","Understand grammar step by step.","Ask the AI Tutor: “Explain basic Sindhi grammar with simple examples in Urdu and English.”"]
  }[view];
  $("pageTitle").textContent=data[1];$("toolIcon").textContent=data[0];$("toolHeading").textContent=data[1];$("toolDescription").textContent=data[2];$("toolCard").textContent=data[3];
  $("sidebar").classList.remove("open");
}));
$("voiceBtn").addEventListener("click",()=>{
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){alert("Voice input is not supported in this browser. Try Chrome.");return;}
  const rec=new SR();rec.lang=({"Sindhi":"ur-PK","Urdu":"ur-PK","English":"en-US"})[$("language").value]||"ur-PK";
  rec.onresult=e=>{$("promptInput").value=e.results[0][0].transcript;};rec.start();
});
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
