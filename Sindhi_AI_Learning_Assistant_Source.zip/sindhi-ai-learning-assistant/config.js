// Fill these with your Supabase project values after setting up the secure Edge Function.
// Never put your Gemini API key in this file.
window.APP_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY"
};