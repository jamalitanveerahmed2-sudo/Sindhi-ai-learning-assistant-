import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const apiKey = Deno.env.get("GEMINI_API_KEY");
    if (!apiKey) throw new Error("GEMINI_API_KEY secret is not configured.");
    const { messages = [], language = "auto" } = await req.json();
    if (!Array.isArray(messages) || messages.length === 0) {
      return new Response(JSON.stringify({ error: "Please send a message." }), {
        status: 400, headers: { ...cors, "Content-Type": "application/json" }
      });
    }
    const system = `You are Sindhi AI Learning Assistant, a friendly and accurate tutor for learners.
Reply in the language requested by the user. If language preference is auto, detect the user's message language.
Support Sindhi (Arabic script), Urdu and English. For Sindhi, use natural Sindhi script.
Explain clearly at an age-appropriate level. For learning questions, include examples.
If uncertain, say so rather than inventing facts. Be respectful and concise.
Selected language preference: ${language}.`;
    const contents = messages.slice(-16).map((m: {role:string;content:string}) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: String(m.content).slice(0, 6000) }]
    }));
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + encodeURIComponent(apiKey),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
        })
      }
    );
    const result = await response.json();
    if (!response.ok) {
      const msg = result?.error?.message || `Gemini request failed (${response.status})`;
      return new Response(JSON.stringify({ error: msg }), {
        status: response.status, headers: { ...cors, "Content-Type": "application/json" }
      });
    }
    const reply = result?.candidates?.[0]?.content?.parts?.map((p: {text?:string})=>p.text||"").join("").trim();
    if (!reply) throw new Error("The AI returned an empty response. Please try again.");
    return new Response(JSON.stringify({ reply }), {
      headers: { ...cors, "Content-Type": "application/json" }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message || "Unexpected server error" }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" }
    });
  }
});