SINDHI AI LEARNING ASSISTANT — SOURCE STARTER

Is ZIP mein mobile-friendly web app ka design aur source code hai.
Yeh abhi complete APK nahi hai aur AI tab tak online jawab nahi dega jab tak
Supabase Edge Function aur Gemini secret configure/deploy na ho.

FILES
- index.html, styles.css, app.js: app UI and client logic
- config.js: Supabase project URL + anon key (Gemini key yahan NAHI rakhni)
- supabase/functions/chat/index.ts: secure Gemini backend function
- manifest.webmanifest + sw.js: installable PWA shell/offline cached interface

IMPORTANT SECURITY
Gemini API key ko kabhi index.html, app.js, config.js, public GitHub repo,
ya chat message mein paste na karein. Sirf Supabase Edge Function secret mein rakhein.

SETUP (project owner/developer ke liye)
1. Supabase project banayein/open karein.
2. Supabase CLI se function deploy karein:
   supabase functions deploy chat
3. Gemini key ko secret set karein:
   supabase secrets set GEMINI_API_KEY=YOUR_GEMINI_KEY
4. config.js mein SUPABASE_URL aur SUPABASE_ANON_KEY set karein.
5. Static files ko HTTPS hosting par publish karein.
6. Android Chrome mein hosted URL khol kar menu > Add to Home screen karein.

ANDROID APK
Is source ko APK banane ke liye Capacitor/Android build ya Android Studio workflow
zaroori hai; aam Android phone par ZIP se seedha APK compile nahi hota.
Aapke paas sirf phone hai, isliye pehle PWA ko online host/install karna sabse
aasaan raasta hai. Native APK ke liye cloud build ya computer/developer workflow chahiye.

NOTE
Gemini model/API availability aur free-tier quotas Google badal sakta hai.
API response errors Supabase function logs mein check karein.
