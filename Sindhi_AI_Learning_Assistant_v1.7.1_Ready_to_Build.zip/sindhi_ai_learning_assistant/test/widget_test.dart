import 'package:flutter_test/flutter_test.dart';
import 'package:sindhi_ai_learning_assistant/main.dart';

void main() {
  testWidgets('app opens with the main learning navigation', (tester) async {
    await tester.pumpWidget(const SindhiLearningApp());
    expect(find.text('Sindhi AI Learning Assistant'), findsOneWidget);
    expect(find.text('AI Tutor'), findsNWidgets(2));
    expect(find.text('Learn'), findsOneWidget);
    expect(find.text('Culture'), findsOneWidget);
  });

  testWidgets('culture topics open readable detail pages', (tester) async {
    await tester.pumpWidget(const SindhiLearningApp());
    await tester.tap(find.text('Culture'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Mohenjo-daro'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Indus Valley Civilisation'), findsOneWidget);
    expect(find.text('Think and discuss'), findsOneWidget);
  });
}
