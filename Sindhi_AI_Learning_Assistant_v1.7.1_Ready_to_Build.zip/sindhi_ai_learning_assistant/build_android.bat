@echo off
where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter SDK is not installed or not on PATH.
  echo Install Flutter: https://docs.flutter.dev/get-started/install
  exit /b 1
)

flutter doctor
if errorlevel 1 exit /b 1
flutter pub get
if errorlevel 1 exit /b 1
flutter analyze
if errorlevel 1 exit /b 1
flutter test
if errorlevel 1 exit /b 1
flutter build apk --release
if errorlevel 1 exit /b 1

echo.
echo Build complete: build\app\outputs\flutter-apk\app-release.apk
