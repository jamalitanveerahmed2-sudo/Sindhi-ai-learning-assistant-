# موبائل سے Sindhi AI Learning Assistant کی APK بنائیں

## حصہ 1: GitHub سے APK بنانا
1. ZIP فائل کو اپنے موبائل میں محفوظ کریں اور extract کریں۔
2. GitHub پر نیا repository بنائیں: `sindhi-ai-learning-assistant`۔ اسے Public یا Private رکھ سکتے ہیں۔
3. اس ZIP کے اندر موجود project کے تمام فولڈرز اور فائلیں repository میں upload کریں۔ `sindhi_ai_learning_assistant` فولڈر کے اندر والی فائلیں upload ہوں، outer folder نہیں۔
4. Repository میں **Actions** کھولیں۔ اگر Enable Actions آئے تو اسے دبائیں۔
5. **Build Android APK** workflow چلائیں۔ مکمل ہونے پر run کھولیں اور `sindhi-ai-learning-assistant-apk` artifact ڈاؤن لوڈ کریں۔
6. Artifact ZIP extract کریں، APK پر tap کریں اور install کریں۔

## حصہ 2: اصلی AI (Gemini) جوڑنا
1. Google AI Studio میں API key بنائیں: https://aistudio.google.com/app/apikey
2. Render یا کسی Node.js hosting پر `server` فولڈر deploy کریں۔ Node 20 استعمال کریں۔
3. Hosting کے Environment Variables میں `GEMINI_API_KEY` شامل کریں۔ API key صرف server پر رکھیں۔
4. `https://YOUR-SERVER-DOMAIN/health` کھولیں؛ `ok: true` آنا چاہیے۔
5. GitHub repository میں Settings → Secrets and variables → Actions → Variables میں `API_BASE_URL` نام کا variable بنائیں اور اس میں server کا HTTPS address لکھیں، آخر میں `/chat` نہ لگائیں۔
6. GitHub Actions میں **Build Android APK** دوبارہ چلائیں۔ اب نئی APK live Gemini AI سے جڑ سکے گی۔

## نوٹ
- Gemini free tier میں limits ہوتی ہیں؛ یہ ہمیشہ لامحدود یا guaranteed free نہیں ہے۔
- API key کسی کو نہ بھیجیں اور Flutter code میں نہ لکھیں۔
- پہلی APK live server کے بغیر offline sample answers دے گی۔
- APK صرف تب تیار ہوگی جب GitHub Actions build کامیابی سے مکمل کرے گا۔
