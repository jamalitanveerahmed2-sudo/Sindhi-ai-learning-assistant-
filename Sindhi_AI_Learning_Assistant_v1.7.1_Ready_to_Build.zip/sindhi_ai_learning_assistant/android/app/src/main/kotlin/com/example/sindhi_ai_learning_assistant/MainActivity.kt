package com.example.sindhi_ai_learning_assistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
