#!/usr/bin/env bash
set -euo pipefail
if ! command -v flutter >/dev/null 2>&1; then
  echo "ERROR: Flutter SDK is not installed or not on PATH."
  exit 1
fi
flutter doctor
flutter pub get
flutter analyze
flutter test
flutter build apk --release --dart-define=API_BASE_URL="${API_BASE_URL:-}"
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
