import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const SindhiLearningApp());

const ink = Color(0xFF17324D);
const teal = Color(0xFF087E78);
const cream = Color(0xFFF5F8F7);

class SindhiLearningApp extends StatelessWidget {
  const SindhiLearningApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Sindhi AI Learning Assistant', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: teal), scaffoldBackgroundColor: cream,
      appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: ink, elevation: 0)),
    home: const MainShell(),
  );
}

class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState()=>_MainShellState(); }
class _MainShellState extends State<MainShell> {
  int tab=0;
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: IndexedStack(index:tab,children:const [HomePage(),ChatPage(),LearnPage(),CulturePage()])),
    bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),
      destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),NavigationDestination(icon:Icon(Icons.chat_outlined),label:'AI Tutor'),NavigationDestination(icon:Icon(Icons.school_outlined),label:'Learn'),NavigationDestination(icon:Icon(Icons.auto_stories_outlined),label:'Culture')]),
  );
}

class HomePage extends StatelessWidget { const HomePage({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
  const SizedBox(height:12),const Text('السلام عليڪم!',textDirection:TextDirection.rtl,style:TextStyle(fontSize:30,fontWeight:FontWeight.bold,color:ink)),
  const Text('Sindhi AI Learning Assistant',style:TextStyle(color:teal,fontWeight:FontWeight.w700,fontSize:17)),const SizedBox(height:22),
  Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(gradient:const LinearGradient(colors:[teal,Color(0xFF145B70)]),borderRadius:BorderRadius.circular(24)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Learn Sindhi.\nKeep your culture alive.',style:TextStyle(color:Colors.white,fontSize:25,fontWeight:FontWeight.bold)),SizedBox(height:8),Text('سنڌي • اردو • English',style:TextStyle(color:Colors.white70,fontSize:17)),SizedBox(height:14),Icon(Icons.menu_book_rounded,color:Colors.white,size:42)])),
  const SizedBox(height:22),const Text('Explore learning tools',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold,color:ink)),const SizedBox(height:10),
  const FeatureRow(icon:Icons.chat,title:'AI Tutor',detail:'Ask questions and practise'),FeatureRow(icon:Icons.abc,title:'Sindhi alphabet',detail:'Letters, sounds and examples'),FeatureRow(icon:Icons.menu_book,title:'Daily lessons',detail:'Vocabulary, grammar and kids learning'),FeatureRow(icon:Icons.quiz,title:'Knowledge quiz',detail:'Test your Sindhi vocabulary'),
  const SizedBox(height:14),const Text('سنڌي ٻولي، اسان جي سڃاڻپ',textDirection:TextDirection.rtl,textAlign:TextAlign.center,style:TextStyle(fontSize:19,color:teal,fontWeight:FontWeight.w600)),
 ]);
}
class FeatureRow extends StatelessWidget {final IconData icon;final String title,detail;const FeatureRow({super.key,required this.icon,required this.title,required this.detail});
 @override Widget build(BuildContext context)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:teal.withOpacity(.1),child:Icon(icon,color:teal)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(detail)));}

class ChatPage extends StatefulWidget {const ChatPage({super.key});@override State<ChatPage> createState()=>_ChatPageState();}
class _ChatPageState extends State<ChatPage>{
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL');
  final input=TextEditingController();
  final List<(bool,String)> msgs=[];
  bool sending=false;

  String offlineAnswer(String q){
    final s=q.toLowerCase();
    if(s.contains('hello')||s.contains('سلام'))return 'سلام! ڀلي ڪري آيا. اڄ ڪهڙو سنڌي لفظ سکڻ چاهيو ٿا؟';
    if(s.contains('good morning'))return 'Good morning = صبح جو سلام (Subh jo salaam).';
    if(s.contains('goodbye')||s.contains('خدا حافظ'))return 'Goodbye = خدا حافظ (Khuda hafiz).';
    if(s.contains('love')||s.contains('پيار'))return 'Love = پيار (Pyaar). مثال: مون کي سنڌي ٻوليءَ سان پيار آهي.';
    if(s.contains('school')||s.contains('اسڪول'))return 'School = اسڪول (School). مثال: مان اسڪول وڃان ٿو.';
    if(s.contains('friend')||s.contains('دوست'))return 'Friend = دوست (Dost). مثال: هو منهنجو دوست آهي.';
    if(s.contains('house')||s.contains('home')||s.contains('گهر'))return 'Home / House = گهر (Ghar).';
    if(s.contains('thank'))return 'Thank you = مهرباني (Meharbani).';
    if(s.contains('پاني')||s.contains('water'))return 'Water = پاڻي (Pāṇī). مثال: مون کي پاڻي گهرجي.';
    if(s.contains('ماء')||s.contains('mother'))return 'Mother = امڙ / ماءُ (Amma / Māu).';
    if(s.contains('book')||s.contains('ڪتاب'))return 'Book = ڪتاب (Kitāb).';
    if(s.contains('ڪيئن')||s.contains('how are'))return 'How are you? = توهان ڪيئن آهيو؟';
    return 'آف لائن موڊ ۾ هن سوال جو جواب موجود ناهي. مڪمل AI جوابن لاءِ محفوظ سرور ڳنڍيو.';
  }

  Future<void> send() async {
    final q=input.text.trim();
    if(q.isEmpty||sending)return;
    input.clear();
    setState((){msgs.add((true,q));sending=true;});
    try {
      String reply;
      if(apiBaseUrl.trim().isEmpty){
        await Future<void>.delayed(const Duration(milliseconds:250));
        reply=offlineAnswer(q);
      } else {
        final history=msgs.take(msgs.length-1).toList();
        final payload=[...history.map((m)=>{'role':m.$1?'user':'assistant','content':m.$2}),{'role':'user','content':q}];
        final response=await http.post(Uri.parse('${apiBaseUrl.replaceFirst(RegExp(r'/+$'), '')}/chat'),
          headers:{'Content-Type':'application/json'},
          body:jsonEncode({'messages':payload}),
        ).timeout(const Duration(seconds:45));
        if(response.statusCode!=200){
          String detail='Server error (${response.statusCode}).';
          try{detail=(jsonDecode(response.body) as Map)['error']?.toString()??detail;}catch(_){}
          throw Exception(detail);
        }
        final data=jsonDecode(response.body) as Map<String,dynamic>;
        reply=(data['reply']??'').toString().trim();
        if(reply.isEmpty)throw Exception('AI server returned an empty answer.');
      }
      if(mounted)setState(()=>msgs.add((false,reply)));
    } catch(e){
      if(mounted)setState(()=>msgs.add((false,'معاف ڪجو، AI سان رابطو نه ٿي سگهيو. ${e.toString().replaceFirst('Exception: ','')}')));
    } finally {if(mounted)setState(()=>sending=false);}
  }
  @override void dispose(){input.dispose();super.dispose();}
  TextDirection directionFor(String value) {
    final hasArabicScript = RegExp(r'[\u0600-\u06FF]').hasMatch(value);
    return hasArabicScript ? TextDirection.rtl : TextDirection.ltr;
  }
  @override Widget build(BuildContext context)=>Column(children:[
    Row(children:[const Expanded(child:Header(title:'Sindhi AI Tutor',subtitle:'Practise Sindhi, Urdu and English')),if(msgs.isNotEmpty)IconButton(tooltip:'Clear conversation',onPressed:sending?null:()=>setState(msgs.clear),icon:const Icon(Icons.delete_outline,color:ink))]),
    Expanded(child:msgs.isEmpty?const Center(child:Padding(padding:EdgeInsets.all(28),child:Text('سلام! مون کان سنڌي لفظن، جملن ۽ گرامر بابت پڇو.\n\nAsk in Sindhi, Roman Sindhi, Urdu or English.',textAlign:TextAlign.center,textDirection:TextDirection.rtl,style:TextStyle(fontSize:18,height:1.7)))):ListView.builder(padding:const EdgeInsets.all(16),itemCount:msgs.length+(sending?1:0),itemBuilder:(c,i){if(i==msgs.length)return const Align(alignment:Alignment.centerLeft,child:Padding(padding:EdgeInsets.all(12),child:SizedBox(width:22,height:22,child:CircularProgressIndicator(strokeWidth:2))));final m=msgs[i];return Align(alignment:m.$1?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.only(bottom:9),padding:const EdgeInsets.all(13),constraints:const BoxConstraints(maxWidth:310),decoration:BoxDecoration(color:m.$1?teal.withOpacity(.13):Colors.white,borderRadius:BorderRadius.circular(15)),child:Text(m.$2,textDirection:directionFor(m.$2))));})),
    Padding(padding:const EdgeInsets.fromLTRB(14,8,14,14),child:Row(children:[Expanded(child:TextField(controller:input,onSubmitted:(_)=>send(),textInputAction:TextInputAction.send,decoration:InputDecoration(hintText:'Write a question...',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none)))),const SizedBox(width:8),IconButton.filled(onPressed:sending?null:send,icon:const Icon(Icons.send))]))
  ]);
}

class LearnPage extends StatelessWidget{const LearnPage({super.key});static const lessons=[('Sindhi Alphabet','سنڌي اکر','Learn letters and their sounds.'),('Daily Vocabulary','روزمره جا لفظ','Common words for everyday conversations.'),('Basic Grammar','بنيادي گرامر','Build simple sentences and questions.'),('Kids Learning','ٻارن لاءِ سکيا','Easy words, colours, numbers and animals.')];
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[const Header(title:'Learn Sindhi',subtitle:'Short lessons for every learner'),const SizedBox(height:12),Card(color:teal.withOpacity(.08),child:ListTile(leading:const CircleAvatar(backgroundColor:teal,child:Icon(Icons.quiz,color:Colors.white)),title:const Text('Quick knowledge quiz',style:TextStyle(fontWeight:FontWeight.bold)),subtitle:const Text('Test five everyday Sindhi words'),trailing:const Icon(Icons.arrow_forward_ios,size:16),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const QuizPage())))),const SizedBox(height:8),...lessons.map((l)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.menu_book,color:teal),backgroundColor:Color(0xFFE4F2EF)),title:Text(l.$1,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${l.$2}\n${l.$3}',textDirection:TextDirection.rtl),isThreeLine:true,trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LessonDetail(title:l.$1,subtitle:l.$2,description:l.$3)))))]);}

class QuizPage extends StatefulWidget{const QuizPage({super.key});@override State<QuizPage> createState()=>_QuizPageState();}
class _QuizPageState extends State<QuizPage>{
 static const questions=<({String prompt,List<String> options,int correct,String meaning})>[
  (prompt:'What does پاڻي mean?',options:['Book','Water','Mother'],correct:1,meaning:'پاڻي means water.'),
  (prompt:'How do you say “Thank you”?',options:['مهرباني','خدا حافظ','سلام'],correct:0,meaning:'مهرباني means thank you.'),
  (prompt:'What does ڪتاب mean?',options:['House','Friend','Book'],correct:2,meaning:'ڪتاب means book.'),
  (prompt:'Choose the Sindhi greeting.',options:['سلام','پاڻي','امڙ'],correct:0,meaning:'سلام is a common greeting.'),
  (prompt:'What does ماءُ mean?',options:['Mother','Sun','School'],correct:0,meaning:'ماءُ means mother.'),
 ];
 int index=0,score=0;int? selected;bool finished=false;
 void choose(int value){if(selected!=null)return;setState((){selected=value;if(value==questions[index].correct)score++;});}
 void next(){if(index==questions.length-1){setState(()=>finished=true);}else{setState((){index++;selected=null;});}}
 void restart()=>setState((){index=0;score=0;selected=null;finished=false;});
 @override Widget build(BuildContext context){if(finished)return Scaffold(appBar:AppBar(title:const Text('Quiz result')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.emoji_events,color:teal,size:76),const SizedBox(height:16),Text('You scored $score / ${questions.length}',style:const TextStyle(fontSize:26,fontWeight:FontWeight.bold,color:ink)),const SizedBox(height:8),Text(score>=4?'Excellent work!':'Good practice. Keep learning!'),const SizedBox(height:22),FilledButton.icon(onPressed:restart,icon:const Icon(Icons.refresh),label:const Text('Try again'))]))));final q=questions[index];return Scaffold(appBar:AppBar(title:const Text('Sindhi Word Quiz')),body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[LinearProgressIndicator(value:(index+1)/questions.length,color:teal),const SizedBox(height:18),Text('Question ${index+1} of ${questions.length}',style:const TextStyle(color:Colors.black54)),const SizedBox(height:16),Text(q.prompt,style:const TextStyle(fontSize:23,fontWeight:FontWeight.bold,color:ink)),const SizedBox(height:18),for(int i=0;i<q.options.length;i++)Padding(padding:const EdgeInsets.only(bottom:10),child:OutlinedButton(onPressed:()=>choose(i),style:OutlinedButton.styleFrom(padding:const EdgeInsets.all(16),backgroundColor:selected==i?(i==q.correct?Colors.green.withOpacity(.12):Colors.red.withOpacity(.10)):Colors.white,side:BorderSide(color:selected!=null&&i==q.correct?Colors.green:Colors.black12)),child:Text(q.options[i],style:const TextStyle(fontSize:18)))),if(selected!=null)Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:teal.withOpacity(.08),borderRadius:BorderRadius.circular(14)),child:Text('${selected==q.correct?'Correct!':'Not quite.'} ${q.meaning}')),const Spacer(),FilledButton(onPressed:selected==null?null:next,child:Text(index==questions.length-1?'See result':'Next question'))])));}
}
class LessonDetail extends StatelessWidget {
  final String title, subtitle, description;
  const LessonDetail({super.key, required this.title, required this.subtitle, required this.description});

  static const lessonWords = <String, List<(String, String, String)>>{
    'Sindhi Alphabet': [
      ('ا', 'انب', 'Mango'), ('ب', 'بدڪ', 'Duck'), ('ٻ', 'ٻڪري', 'Goat'), ('ڀ', 'ڀٽ', 'Dune'),
      ('پ', 'پاڻي', 'Water'), ('ت', 'تارو', 'Star'), ('ٿ', 'ٿانو', 'Bowl'), ('ج', 'جبل', 'Mountain'),
      ('چ', 'چنڊ', 'Moon'), ('د', 'در', 'Door'), ('ر', 'رستو', 'Road'),
      ('س', 'سنڌ', 'Sindh'), ('م', 'ماءُ', 'Mother'), ('ن', 'نانءُ', 'Name'), ('ڪ', 'ڪتاب', 'Book'),
    ],
    'Daily Vocabulary': [
      ('پاڻي', 'پاڻي', 'Water'), ('ماني', 'ماني', 'Bread / meal'),
      ('گهر', 'گهر', 'Home'), ('دوست', 'دوست', 'Friend'),
      ('اسڪول', 'اسڪول', 'School'), ('ڪتاب', 'ڪتاب', 'Book'),
    ],
    'Basic Grammar': [
      ('مان', 'مان شاگرد آهيان.', 'I am a student.'),
      ('تون', 'تون ڪيئن آهين؟', 'How are you? (informal)'),
      ('توهان', 'توهان ڪيئن آهيو؟', 'How are you? (polite)'),
      ('هي', 'هي منهنجو ڪتاب آهي.', 'This is my book.'),
    ],
    'Kids Learning': [
      ('هڪ', 'هڪ', 'One'), ('ٻه', 'ٻه', 'Two'), ('ٽي', 'ٽي', 'Three'),
      ('ڳاڙهو', 'ڳاڙهو', 'Red'), ('سائو', 'سائو', 'Green'),
      ('ٻلي', 'ٻلي', 'Cat'), ('ڪتو', 'ڪتو', 'Dog'),
    ],
  };

  @override
  Widget build(BuildContext context) {
    final words = lessonWords[title] ?? lessonWords['Daily Vocabulary']!;
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(padding: const EdgeInsets.all(22), children: [
        Text(subtitle, textDirection: TextDirection.rtl,
            style: const TextStyle(fontSize: 30, color: teal, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Text(description, style: const TextStyle(fontSize: 17, height: 1.5)),
        const SizedBox(height: 20),
        const Text('Learn and practise', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...words.map((w) => WordLine(w.$1, '${w.$2}  —  ${w.$3}')),
        const SizedBox(height: 18),
        Container(padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: teal.withOpacity(.08), borderRadius: BorderRadius.circular(16)),
          child: const Text('Practice tip: Say each word aloud three times, then try using it in a short sentence.',
              style: TextStyle(height: 1.5))),
      ]),
    );
  }
}
class WordLine extends StatelessWidget{final String letter,word;const WordLine(this.letter,this.word,{super.key});@override Widget build(BuildContext context)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:teal.withOpacity(.1),child:Text(letter,style:const TextStyle(fontSize:23,color:teal))),title:Text(word)));}

class CulturePage extends StatelessWidget {
  const CulturePage({super.key});
  static const topics = <({IconData icon, String title, String detail, String body})>[
    (icon: Icons.account_balance, title: 'History of Sindh', detail: 'Ancient settlements, kingdoms and modern Sindh.', body: 'Sindh has a long history shaped by the Indus River. Its heritage includes ancient settlements, regional kingdoms, trade, literature and a vibrant modern society. The Indus has supported farming and communities for thousands of years.'),
    (icon: Icons.temple_buddhist, title: 'Mohenjo-daro', detail: 'An important city of the Indus Valley Civilisation.', body: 'Mohenjo-daro is one of the best-known cities of the Indus Valley Civilisation. Its planned streets, baked-brick buildings, drainage system and public structures show impressive urban organisation from the Bronze Age.'),
    (icon: Icons.music_note, title: 'Sufi heritage', detail: 'Poetry and teachings of Shah Abdul Latif Bhittai and other Sufi poets.', body: 'Sindhi Sufi poetry often explores love, compassion, humility and the search for truth. Shah Abdul Latif Bhittai is a central literary figure; his poetry is preserved in the Shah Jo Risalo and remains part of Sindh’s musical and cultural life.'),
    (icon: Icons.diversity_3, title: 'Traditions & crafts', detail: 'Ajrak, Sindhi topi, folk music, embroidery and festivals.', body: 'Ajrak is a distinctive block-printed textile, while the Sindhi topi is a recognisable traditional cap. Regional crafts also include embroidery, ralli quilts, pottery and folk music. Traditions vary across communities and districts.'),
  ];
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Header(title: 'Sindh: History & Culture', subtitle: 'Explore a rich and living heritage'),
    const SizedBox(height: 12),
    ...topics.map((topic) => Card(child: ListTile(
      contentPadding: const EdgeInsets.all(15),
      leading: CircleAvatar(backgroundColor: teal.withOpacity(.1), child: Icon(topic.icon, color: teal)),
      title: Text(topic.title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(topic.detail), trailing: const Icon(Icons.chevron_right),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CultureDetailPage(title: topic.title, body: topic.body))),
    ))),
  ]);
}

class CultureDetailPage extends StatelessWidget {
  final String title, body;
  const CultureDetailPage({super.key, required this.title, required this.body});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: ListView(padding: const EdgeInsets.all(22), children: [
      const Icon(Icons.auto_stories, color: teal, size: 58),
      const SizedBox(height: 18),
      Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: ink)),
      const SizedBox(height: 14),
      Text(body, style: const TextStyle(fontSize: 17, height: 1.8)),
      const SizedBox(height: 22),
      const Text('Think and discuss', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('What is one thing you learned about this topic? Try explaining it in Sindhi, Urdu or English.', style: TextStyle(height: 1.6)),
    ]),
  );
}

class Header extends StatelessWidget{final String title,subtitle;const Header({super.key,required this.title,required this.subtitle});@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(top:18,bottom:8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold,color:ink)),const SizedBox(height:4),Text(subtitle,style:const TextStyle(color:Colors.black54))]));}
