# Sindhi AI Learning Assistant

Flutter Android app with a server-side OpenAI Responses API integration (Gemini optional).

See `START_HERE_UR.md` for Urdu deployment and APK build instructions.

**Important:** This repository is source code, not a prebuilt APK. A live AI backend requires a valid provider API key stored only in the hosting environment. Build the APK after setting the GitHub Actions repository variable `API_BASE_URL`.
