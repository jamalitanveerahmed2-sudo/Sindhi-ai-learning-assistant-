import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const port = Number(process.env.PORT || 3000);
const provider = (process.env.AI_PROVIDER || 'openai').toLowerCase();
const openaiKey = process.env.OPENAI_API_KEY;
const openaiModel = process.env.OPENAI_MODEL || 'gpt-5.5';
const geminiKey = process.env.GEMINI_API_KEY;
const geminiModel = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

if (provider === 'openai' && !openaiKey) {
  console.error('Missing OPENAI_API_KEY. Add it to the hosting service environment; never put it in the Android app.');
  process.exit(1);
}
if (provider === 'gemini' && !geminiKey) {
  console.error('Missing GEMINI_API_KEY. Add it to the hosting service environment; never put it in the Android app.');
  process.exit(1);
}
if (!['openai', 'gemini'].includes(provider)) {
  console.error('AI_PROVIDER must be either openai or gemini.');
  process.exit(1);
}

app.use(helmet());
app.use(express.json({ limit: '32kb' }));
const origins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin: origins.length ? origins : false }));
app.use('/chat', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

const tutorInstructions = [
  'You are Sindhi AI Learning Assistant, a patient and accurate language tutor.',
  'Support Sindhi script, Roman Sindhi, Urdu, and English. Reply in the language and script used by the learner unless they ask otherwise.',
  'For language learning, explain meanings, pronunciation/transliteration when useful, and give short examples.',
  'Be respectful of Sindhi culture. If uncertain about a dialect, spelling, or fact, say so instead of inventing an answer.',
  'Keep answers clear and suitable for students. Do not claim to be a human teacher.'
].join(' ');

app.get('/health', (_req, res) => res.json({ ok: true, app: 'Sindhi AI Learning Assistant', provider }));

app.post('/chat', async (req, res) => {
  try {
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20) {
      return res.status(400).json({ error: 'Please send between 1 and 20 chat messages.' });
    }
    const normalized = messages.map(m => {
      if (!['user', 'assistant'].includes(m?.role) || typeof m?.content !== 'string') throw new Error('Invalid message format.');
      const content = m.content.trim();
      if (!content || content.length > 4000) throw new Error('Each message must be 1–4000 characters.');
      return { role: m.role, content };
    });
    if (!normalized.some(m => m.role === 'user')) return res.status(400).json({ error: 'A user message is required.' });

    let reply = '';
    if (provider === 'openai') {
      const response = await fetch('https://api.openai.com/v1/responses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${openaiKey}` },
        body: JSON.stringify({ model: openaiModel, instructions: tutorInstructions, input: normalized, max_output_tokens: 900 })
      });
      const data = await response.json();
      if (!response.ok) {
        console.error('OpenAI API error:', response.status, data?.error?.message || 'Unknown error');
        const status = response.status === 429 ? 429 : 502;
        return res.status(status).json({ error: response.status === 429 ? 'AI usage limit reached. Please check API billing/limits and try again.' : 'OpenAI service request failed. Check the server API key, model access, and billing.' });
      }
      reply = (data.output || []).flatMap(item => item.content || []).filter(part => part.type === 'output_text').map(part => part.text || '').join('').trim();
      if (!reply && typeof data.output_text === 'string') reply = data.output_text.trim();
    } else {
      const contents = normalized.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
      const turns = [];
      for (const turn of contents) {
        const last = turns[turns.length - 1];
        if (last && last.role === turn.role) last.parts[0].text += '\n' + turn.parts[0].text;
        else turns.push(turn);
      }
      if (turns[0]?.role !== 'user') turns.shift();
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(geminiModel)}:generateContent`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': geminiKey },
        body: JSON.stringify({ systemInstruction: { parts: [{ text: tutorInstructions }] }, contents: turns, generationConfig: { temperature: 0.6, maxOutputTokens: 900 } })
      });
      const data = await response.json();
      if (!response.ok) {
        console.error('Gemini API error:', response.status, data?.error?.message || 'Unknown error');
        return res.status(response.status === 429 ? 429 : 502).json({ error: 'Gemini service request failed. Check the server API key, model settings, and usage limits.' });
      }
      reply = data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim() || '';
    }
    if (!reply) return res.status(502).json({ error: 'The AI service returned no text. Please try again.' });
    res.json({ reply });
  } catch (error) {
    console.error('Chat request failed:', error?.message || error);
    res.status(500).json({ error: error?.message || 'The AI service is temporarily unavailable. Please try again.' });
  }
});

app.listen(port, '0.0.0.0', () => console.log(`Sindhi AI server listening on port ${port} using ${provider}`));
