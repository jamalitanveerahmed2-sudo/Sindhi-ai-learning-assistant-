# سندھی اے آئی لرننگ اسسٹنٹ — OpenAI سیٹ اپ

یہ Flutter Android سورس پراجیکٹ ہے، APK فائل نہیں۔ ایپ میں حقیقی ChatGPT/OpenAI جواب چلانے کے لیے پہلے سرور Deploy کرنا اور پھر اس سرور کا URL دے کر APK بنانا ضروری ہے۔

## 1) OpenAI API سرور
1. OpenAI Platform پر API key بنائیں: https://platform.openai.com/api-keys
2. اس پروجیکٹ کو GitHub repository میں اپ لوڈ کریں۔
3. Render پر New → Blueprint منتخب کر کے repository connect کریں؛ `render.yaml` سروس کی ترتیب فراہم کرتا ہے۔ متبادل طور پر Node سروس بنائیں، Root Directory `server`، Build Command `npm install`، Start Command `npm start` رکھیں۔
4. Render → سروس → Environment میں `OPENAI_API_KEY` بنائیں اور اپنی key وہاں محفوظ کریں۔ `AI_PROVIDER=openai` اور `OPENAI_MODEL=gpt-5.5` مقرر رکھیں۔ اگر آپ کے API اکاؤنٹ میں یہ ماڈل دستیاب نہ ہو تو دستیاب ماڈل کا نام `OPENAI_MODEL` میں دیں۔
5. Deploy کے بعد `https://YOUR-SERVICE.onrender.com/health` کھولیں۔ کامیابی پر `ok: true` اور `provider: openai` نظر آنا چاہیے۔

## 2) APK بنائیں
1. GitHub repository میں Settings → Secrets and variables → Actions → Variables کھولیں۔
2. `API_BASE_URL` نام کا Repository Variable بنائیں۔ Value میں Render کا بنیادی HTTPS URL دیں، مثلاً `https://your-service.onrender.com`؛ آخر میں `/chat` نہ لگائیں۔
3. Actions → Build Android APK → Run workflow چلائیں۔
4. کامیاب workflow کے Artifacts حصے سے `sindhi-ai-learning-assistant-apk` ڈاؤن لوڈ کریں؛ اس ZIP کے اندر `app-release.apk` ہوگا۔

## سکیورٹی اور بلنگ
- `OPENAI_API_KEY` صرف Render Environment میں رکھیں۔ اسے Flutter، APK، GitHub source یا چیٹ میں ہرگز شامل نہ کریں۔
- ChatGPT کی Plus/Pro سبسکرپشن اور API billing الگ ہیں؛ API استعمال کے لیے OpenAI Platform پر API billing فعال ہونا ضروری ہو سکتا ہے۔
- اس ماحول میں Flutter/Android SDK موجود نہیں، اس لیے یہاں APK compile یا install test نہیں کیا جا سکا۔ GitHub Actions اسے build کرے گا۔

## Gemini متبادل
Render Environment میں `AI_PROVIDER=gemini`، `GEMINI_API_KEY` اور اختیاری `GEMINI_MODEL=gemini-2.5-flash` مقرر کریں۔
