سندھی AI اسسٹنٹ — میسج بھیجنے اور AI جواب وصول کرنے والا ورژن

اس پیکج میں آپ کی موجودہ HTML ایپ برقرار رکھی گئی ہے۔ میسج باکس اب حقیقی /chat API سے رابطہ کرتا ہے، جواب آنے تک انتظار دکھاتا ہے، اور غلطی کی صورت میں پیغام دیتا ہے۔

اہم: فرنٹ اینڈ اور سرور کوڈ تیار ہے، مگر AI جواب تبھی آئے گا جب سرور آن لائن deploy ہو اور اس کے Environment میں OPENAI_API_KEY موجود ہو۔ API key کبھی index.html یا APK میں نہ ڈالیں۔ OpenAI API کی billing، ChatGPT سبسکرپشن سے الگ ہو سکتی ہے۔

سرور چلانے کا طریقہ:
1) اس فولڈر کے server فولڈر کو Node.js 20+ hosting (مثلاً Render) پر deploy کریں۔ render.yaml blueprint بھی ساتھ ہے۔
2) Hosting کے Environment Variables میں OPENAI_API_KEY اپنی خفیہ key کے طور پر شامل کریں۔ OPENAI_MODEL اختیاری ہے (default gpt-5.5)۔
3) Deploy کے بعد https://YOUR-SERVICE.onrender.com/health کھولیں؛ {"ok":true} آنا چاہیے۔
4) ایپ کھولیں، ☰ مینو > AI Server Settings، اور اپنے سرور کا HTTPS base URL درج کریں۔ آخر میں /chat نہ لکھیں۔
5) اب میسج لکھ کر Send دبائیں؛ جواب چیٹ میں آ جائے گا۔

حفاظت: API key صرف hosting کے environment میں رہے گی۔ اسے کسی کو چیٹ میں نہ بھیجیں۔

یہ HTML/PWA فرنٹ اینڈ اور Node.js backend پیکج ہے، Android APK نہیں۔ APK بنانے کے لیے اسے Android wrapper/Flutter project میں شامل کر کے Android build کرنا ہوگا۔
