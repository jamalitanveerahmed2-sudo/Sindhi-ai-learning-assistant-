const http = require('node:http');
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.5';
const INSTRUCTIONS = `You are Sindhi AI Assistant, a friendly educational tutor. Reply in the same language the user uses: Sindhi script for Sindhi, Urdu script for Urdu, and English for English. Support Roman Sindhi too. Be accurate, patient, clear, and concise. Help with Sindhi language, culture, translation, school learning, and general knowledge. Do not claim to be human.`;
const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const send = (status, data) => { res.writeHead(status, {'Content-Type':'application/json; charset=utf-8'}); res.end(JSON.stringify(data)); };
  if (req.method === 'GET' && req.url === '/health') return send(200, {ok:true, service:'Sindhi AI Assistant'});
  if (req.method !== 'POST' || req.url !== '/chat') return send(404, {error:'Not found'});
  if (!API_KEY) return send(503, {error:'Server administrator must configure OPENAI_API_KEY.'});
  let raw='';
  for await (const chunk of req) { raw += chunk; if (raw.length > 100000) return send(413,{error:'Request too large'}); }
  try {
    const body = JSON.parse(raw || '{}');
    const messages = Array.isArray(body.messages) ? body.messages.slice(-14) : [];
    const input = messages.filter(m => ['user','assistant'].includes(m.role) && typeof m.content === 'string').map(m => ({role:m.role, content:m.content.slice(0,6000)}));
    if (!input.length || input[input.length-1].role !== 'user') return send(400,{error:'Please send a message first.'});
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method:'POST', headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({model:MODEL, instructions:INSTRUCTIONS, input, max_output_tokens:1200})
    });
    const result = await upstream.json();
    if (!upstream.ok) return send(upstream.status,{error:result.error?.message || 'OpenAI API request failed.'});
    const reply = result.output_text || (result.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('\n');
    if (!reply) return send(502,{error:'No text was returned by the AI service.'});
    return send(200,{reply});
  } catch (e) { return send(400,{error:'Invalid request or network error.'}); }
});
server.listen(PORT, () => console.log(`Sindhi AI server listening on ${PORT}`));
