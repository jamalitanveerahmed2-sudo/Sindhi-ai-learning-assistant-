# سندھی اے آئی لرننگ اسسٹنٹ — شروع کرنے کا طریقہ

آپ کی ایپ کا Android/Flutter سورس، AI چیٹ، ترجمہ اسکرین، Gemini سرور اور APK بنانے کا GitHub Actions ورک فلو اس پیکج میں شامل ہیں۔

## اہم بات
یہ ZIP خود APK نہیں ہے۔ اس ماحول میں Flutter/Android SDK موجود نہیں، اس لیے میں یہاں APK compile اور فون پر install کر کے ٹیسٹ نہیں کر سکتا۔ اسی طرح حقیقی AI جواب کے لیے آپ کی اپنی Gemini API key درکار ہے؛ میں آپ کے نام سے key نہیں بنا سکتا۔ API key صرف سرور پر رکھی جائے گی، موبائل ایپ میں نہیں۔

## حقیقی AI چیٹ فعال کرنے کے مراحل
1. Google AI Studio میں اپنی Gemini API key بنائیں: https://aistudio.google.com/app/apikey
2. اس پروجیکٹ کا `server` فولڈر Node.js 20 والے hosting provider پر deploy کریں۔ `render.yaml` میں Render کی بنیادی ترتیب موجود ہے۔
3. Hosting dashboard میں `GEMINI_API_KEY` نام کا Secret/Environment Variable بنائیں اور اپنی key وہاں رکھیں۔ `GEMINI_MODEL` کی default قدر `gemini-2.5-flash` ہے۔
4. Deploy ہونے کے بعد `https://آپ-کا-سرور/health` کھولیں۔ جواب میں `ok: true` آنا چاہیے۔
5. پروجیکٹ GitHub repository میں upload کریں۔ GitHub → Settings → Secrets and variables → Actions → Variables میں `API_BASE_URL` بنائیں اور صرف سرور کا HTTPS base address دیں، آخر میں `/chat` نہ لگائیں۔
6. GitHub → Actions → **Build Android APK** → **Run workflow** دبائیں۔ کامیاب build کے بعد `sindhi-ai-learning-assistant-apk` artifact ڈاؤن لوڈ کریں۔ ZIP کھول کر APK فون میں install کریں۔

## ایپ میں کیا ہے؟
- Home، AI Tutor، Learn اور Culture صفحات
- سندھی، اردو، رومن سندھی اور انگریزی سوالات کے لیے AI Tutor
- حقیقی Gemini جواب اور سندھی/اردو/انگریزی/رومن سندھی ترجمے کے لیے محفوظ server-side API
- چیٹ ہسٹری اسی گفتگو کے دوران بھیجنے کی سہولت
- سندھی حروف، الفاظ، اسباق، کوئز اور ثقافتی معلومات

## سیکیورٹی
اپنی Gemini API key کسی چیٹ، سورس فائل، APK یا GitHub repository میں نہ لکھیں۔ اسے صرف hosting provider کے محفوظ Environment Variables میں رکھیں۔ Gemini کی مفت استعمال کی حدیں بدل سکتی ہیں۔
