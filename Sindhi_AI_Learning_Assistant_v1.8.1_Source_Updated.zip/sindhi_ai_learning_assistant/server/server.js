import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.GEMINI_API_KEY;
const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
if (!apiKey) {
  console.error('Missing GEMINI_API_KEY. Add it to the server environment; never put it in the Android app.');
  process.exit(1);
}
app.use(helmet());
app.use(express.json({ limit: '32kb' }));
const origins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin: origins.length ? origins : false }));
app.use(['/chat', '/translate'], rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/health', (_req, res) => res.json({ ok: true, app: 'Sindhi AI Learning Assistant', provider: 'Gemini' }));
app.post('/translate', async (req, res) => {
  try {
    const { text, sourceLanguage = 'Auto detect', targetLanguage = 'Sindhi' } = req.body || {};
    if (typeof text !== 'string' || !text.trim() || text.length > 5000) {
      return res.status(400).json({ error: 'Enter text between 1 and 5000 characters.' });
    }
    const allowed = ['Auto detect', 'Sindhi', 'Urdu', 'English', 'Roman Sindhi'];
    if (!allowed.includes(sourceLanguage) || !allowed.includes(targetLanguage) || targetLanguage === 'Auto detect') {
      return res.status(400).json({ error: 'Choose supported source and target languages.' });
    }
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: `You are a careful translator. Translate the user's text from ${sourceLanguage} to ${targetLanguage}. Preserve meaning, tone and formatting. For Sindhi use standard Arabic-based Sindhi script; for Roman Sindhi use Latin letters. Return only the translation, with no preface or explanation. If text is already in target language, return it unchanged.` }] },
        contents: [{ role: 'user', parts: [{ text: text.trim() }] }],
        generationConfig: { temperature: 0.2, maxOutputTokens: 1400 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error('Gemini translation error:', response.status, data?.error?.message || 'Unknown error');
      const status = response.status === 429 ? 429 : 502;
      return res.status(status).json({ error: status === 429 ? 'AI free-tier limit reached. Please wait and try again.' : 'Translation service request failed. Check the server API key and model settings.' });
    }
    const translation = data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();
    if (!translation) return res.status(502).json({ error: 'The translation service returned no text. Please try again.' });
    return res.json({ translation });
  } catch (error) {
    console.error('Translation request failed:', error?.message || error);
    return res.status(500).json({ error: 'Translation is temporarily unavailable. Please try again.' });
  }
});

app.post('/chat', async (req, res) => {
  try {
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20) {
      return res.status(400).json({ error: 'Please send between 1 and 20 chat messages.' });
    }
    const contents = messages.map(m => {
      if (!['user', 'assistant'].includes(m?.role) || typeof m?.content !== 'string') throw new Error('Invalid message format.');
      const content = m.content.trim();
      if (!content || content.length > 4000) throw new Error('Each message must be 1–4000 characters.');
      return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: content }] };
    });
    // Gemini expects alternating user/model turns. Merge adjacent turns defensively.
    const normalized = [];
    for (const turn of contents) {
      const last = normalized[normalized.length - 1];
      if (last && last.role === turn.role) last.parts[0].text += '\n' + turn.parts[0].text;
      else normalized.push(turn);
    }
    if (normalized[0]?.role !== 'user') normalized.shift();
    if (!normalized.length) return res.status(400).json({ error: 'A user message is required.' });

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: [
          'You are Sindhi AI Learning Assistant, a patient and accurate language tutor.',
          'Support Sindhi script, Roman Sindhi, Urdu, and English. Reply in the language and script used by the learner unless they ask otherwise.',
          'For language learning, explain meanings, pronunciation/transliteration when useful, and give short examples.',
          'Be respectful of Sindhi culture. If uncertain about a dialect, spelling, or fact, say so instead of inventing an answer.',
          'Keep answers clear and suitable for students. Do not claim to be a human teacher.'
        ].join(' ') }] },
        contents: normalized,
        generationConfig: { temperature: 0.6, maxOutputTokens: 900 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error('Gemini API error:', response.status, data?.error?.message || 'Unknown error');
      const status = response.status === 401 || response.status === 403 ? 502 : response.status === 429 ? 429 : 502;
      return res.status(status).json({ error: response.status === 429 ? 'AI free-tier limit reached. Please wait and try again.' : 'AI service request failed. Check the server API key and model settings.' });
    }
    const reply = data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();
    if (!reply) return res.status(502).json({ error: 'The AI service returned no text. Please try again.' });
    res.json({ reply });
  } catch (error) {
    console.error('Chat request failed:', error?.message || error);
    res.status(500).json({ error: error?.message || 'The AI service is temporarily unavailable. Please try again.' });
  }
});
app.listen(port, '0.0.0.0', () => console.log(`Sindhi AI server listening on port ${port}`));
