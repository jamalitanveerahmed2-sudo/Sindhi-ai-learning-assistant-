سنڌي AI اسسٽنٽ — OpenAI سان ڳنڍيل ورزن

هن پيڪيج ۾ توهان جي اصل HTML ايپ کي حقيقي AI چيٽ سان ڳنڍيو ويو آهي. API Key محفوظ طور سرور تي رکبي؛ اها HTML/موبائل ايپ ۾ شامل نه آهي.

آن لائن هلائڻ جا قدم (Render):
1) هن ZIP کي پنهنجي ڪمپيوٽر تي Extract ڪريو.
2) https://render.com تي اڪائونٽ کوليو ۽ New > Web Service چونڊيو.
3) هي فولڊر GitHub repository ۾ رکي، Render سان connect ڪريو.
4) Render پاڻ render.yaml پڙهي Node سروس ٺاهي وٺندو. Build: npm install، Start: npm start.
5) Render جي Environment سيڪشن ۾ OPENAI_API_KEY نالي variable ٺاهيو ۽ پنهنجي OpenAI API key اتي paste ڪريو. Key ڪنهن سان به شيئر نه ڪريو ۽ HTML ۾ نه وجهو.
6) Deploy مڪمل ٿيڻ بعد Render توهان کي ويب ايڊريس ڏيندو. اهو کوليو؛ چيٽ باڪس مان پيغام موڪلي AI جواب حاصل ڪري سگهندا.

ضروري:
- API Key هتي چيٽ ۾ نه موڪليو.
- OpenAI API استعمال لاءِ API اڪائونٽ تي فعال بلنگ/ڪريڊٽ گهربل ٿي سگهي ٿو؛ ChatGPT سبسڪرپشن پاڻمرادو API ڪريڊٽ نه هوندي.
- هي پيڪيج ويب ايپ + محفوظ backend آهي، APK نه آهي. APK ٺاهڻ لاءِ الڳ Android wrapper/build قدم گهربل هوندا.
- ڊفالٽ ماڊل gpt-4.1-mini آهي. جيڪڏهن توهان جي API اڪائونٽ ۾ اهو ماڊل موجود نه هجي ته OPENAI_MODEL ۾ پنهنجي دستياب ماڊل جو نالو رکو.

مقامي طور هلائڻ:
1) Node.js 20 يا نئون انسٽال ڪريو.
2) هن فولڊر ۾ Terminal کوليو ۽ npm install هلايو.
3) .env.example جي ڪاپي .env نالي ٺاهيو، ان ۾ OPENAI_API_KEY ڀريو.
4) npm start هلايو ۽ browser ۾ http://localhost:3000 کوليو.
