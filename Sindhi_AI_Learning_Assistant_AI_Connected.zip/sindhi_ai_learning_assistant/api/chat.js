// Vercel serverless function. Keep OPENAI_API_KEY on the server; never put it in browser code.
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'GET') return res.status(200).json({ configured: Boolean(process.env.OPENAI_API_KEY) });
  if (req.method !== 'POST') return res.status(405).json({ error: 'Only POST is allowed.' });
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: 'AI ابھی configure نہیں ہوا۔ سرور پر OPENAI_API_KEY شامل کریں۔' });
  }

  try {
    const { message, history = [], mode = 'tutor', from = 'Urdu', to = 'Sindhi' } = req.body || {};
    if (typeof message !== 'string' || !message.trim()) return res.status(400).json({ error: 'پیغام خالی ہے۔' });
    if (message.length > 2500) return res.status(413).json({ error: 'پیغام بہت طویل ہے؛ اسے 2500 حروف سے کم رکھیں۔' });

    const safeHistory = Array.isArray(history) ? history.slice(-8).filter(x =>
      x && ['user', 'assistant'].includes(x.role) && typeof x.content === 'string'
    ).map(x => ({ role: x.role, content: x.content.slice(0, 2500) })) : [];

    const instructions = `You are Sindhi AI Learning Assistant, a patient expert Sindhi language teacher. Help beginner and intermediate learners. Reply in the language the user uses (Urdu, English, Sindhi or Roman Urdu) unless they request another. When teaching Sindhi, provide correct Sindhi script, simple Roman Sindhi pronunciation, and a clear Urdu or English meaning where useful. Explain grammar simply, correct mistakes gently, give short examples and small practice questions. Distinguish standard Sindhi from regional variants when relevant; never invent certainty. Keep answers friendly, clear and reasonably concise. For translations, translate naturally from ${from} to ${to}; output the translation first, then a brief note only if needed. Do not claim to be human.`;

    const input = mode === 'translate'
      ? `Translate the following text from ${from} to ${to}:\n${message}`
      : [...safeHistory, { role: 'user', content: message }];

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-5.5', instructions, input, max_output_tokens: 700 })
    });
    const data = await response.json();
    if (!response.ok) {
      const msg = data?.error?.message || 'AI سروس سے جواب نہیں ملا۔';
      return res.status(response.status === 429 ? 429 : 502).json({ error: msg });
    }
    const answer = (data.output || []).flatMap(item => item.content || [])
      .filter(part => part.type === 'output_text').map(part => part.text).join('\n').trim();
    if (!answer) return res.status(502).json({ error: 'AI نے خالی جواب دیا؛ دوبارہ کوشش کریں۔' });
    return res.status(200).json({ answer });
  } catch (err) {
    console.error('AI endpoint error:', err);
    return res.status(500).json({ error: 'عارضی سرور خرابی۔ کچھ دیر بعد دوبارہ کوشش کریں۔' });
  }
}
