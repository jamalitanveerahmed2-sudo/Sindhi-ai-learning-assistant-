# Sindhi AI Learning Assistant

سندھی زبان سیکھنے کے لیے اردو/English انٹرفیس والی Progressive Web App، اب محفوظ server-side AI integration کے ساتھ تیار ہے۔

## خصوصیات
- اردو اور English انٹرفیس
- سندھی حروف، ابتدائی اسباق اور روزمرہ الفاظ
- phrasebook اور محدود جملوں کا مقامی ترجمہ
- **Live AI Tutor**: سندھی زبان، گرامر، تلفظ، مثالوں اور مشق کے سوالات کے جوابات
- **AI Translation**: phrasebook میں نہ ملنے والے جملوں کا AI ترجمہ
- 10 سوالات کا کوئز، مقامی progress محفوظ
- PWA manifest اور service worker
- API key صرف server-side environment variable میں؛ browser میں ظاہر نہیں ہوتی

## AI چلانے کے لیے ضروری چیزیں
Live AI کے لیے OpenAI API key اور ایسا hosting/server درکار ہے جو `api/chat.js` چلا سکے۔ صرف ZIP کو فون میں کھولنے سے Live AI فعال نہیں ہوگا۔

### Vercel پر تعیناتی (GitHub کے بغیر)
1. اس فولڈر کو اپنے کمپیوٹر پر extract کریں۔
2. Vercel CLI اور Node.js 20+ انسٹال کریں۔
3. terminal میں اس فولڈر کے اندر `npm install -g vercel` چلائیں۔
4. `vercel` چلائیں اور Vercel اکاؤنٹ کے ساتھ deploy کریں۔
5. Vercel project کے Settings → Environment Variables میں `OPENAI_API_KEY` شامل کریں۔
6. اختیاری: `OPENAI_MODEL` کی قدر مقرر کریں؛ default `gpt-5.5` ہے۔
7. دوبارہ deploy کریں۔ پھر ویب ایپ میں Tutor اور AI Translation سرور کے ذریعے کام کریں گے۔

### مقامی development
`npm install -g vercel` کے بعد `vercel dev` چلائیں۔ مقامی environment میں `OPENAI_API_KEY` مقرر ہونا ضروری ہے۔ `.env.example` صرف نمونہ ہے؛ اپنی اصل key کو `.env` میں رکھیں اور اسے کبھی share نہ کریں۔

## سیکیورٹی
- API key کو `index.html` یا کسی client-side JavaScript میں نہ ڈالیں۔
- API key صرف hosting provider کے Environment Variables میں رکھیں۔
- API استعمال کے لیے OpenAI اکاؤنٹ پر فعال billing/credit درکار ہو سکتا ہے۔ استعمال کے مطابق فیس لگ سکتی ہے۔

## موجودہ حد
AI integration code شامل ہے، لیکن Live AI تبھی حقیقتاً جواب دے گا جب اسے API key کے ساتھ server پر deploy کیا جائے۔ اس ZIP میں Android APK شامل نہیں۔
