# جلدی شروع کریں — سندھی اے آئی لرننگ اسسٹنٹ

یہ ZIP اینڈرائیڈ ایپ کا سورس کوڈ ہے؛ تیار شدہ APK نہیں۔ ایپ میں حقیقی AI چیٹ چلانے کے لیے سرور اور API key درکار ہے۔

## OpenAI (ChatGPT API) فعال کرنا — تجویز کردہ

1. OpenAI Platform پر API key بنائیں: https://platform.openai.com/api-keys
2. Render پر اس پروجیکٹ کو deploy کریں۔ `render.yaml` میں سرور پہلے سے OpenAI provider کے لیے تیار ہے۔
3. Render Dashboard → آپ کی سروس → Environment میں `OPENAI_API_KEY` کے نام سے اپنی key محفوظ کریں۔ `AI_PROVIDER=openai` اور `OPENAI_MODEL=gpt-5.5` پہلے سے مقرر ہیں۔ اگر آپ کے اکاؤنٹ میں یہ ماڈل دستیاب نہ ہو تو کسی دستیاب ماڈل کا نام `OPENAI_MODEL` میں رکھیں۔
4. Deploy مکمل ہونے کے بعد `https://YOUR-SERVICE.onrender.com/health` کھولیں؛ جواب میں `ok: true` اور `provider: openai` آنا چاہیے۔
5. GitHub repository کی Settings → Secrets and variables → Actions → Variables میں `API_BASE_URL` بنائیں اور اس میں سرور کا بنیادی HTTPS URL دیں، آخر میں `/chat` نہ لگائیں۔
6. Actions → Build Android APK → Run workflow چلائیں اور `sindhi-ai-learning-assistant-apk` artifact ڈاؤن لوڈ کریں۔

## اہم سکیورٹی

- اپنی OpenAI API key مجھے چیٹ میں نہ بھیجیں، اور اسے Flutter/Android ایپ، GitHub source code یا APK میں ہرگز شامل نہ کریں۔ اسے صرف Render کے Environment میں رکھیں۔
- ChatGPT کی سبسکرپشن اور OpenAI API billing الگ ہیں؛ API استعمال کے لیے Platform پر billing/credits فعال ہونا ضروری ہو سکتا ہے۔
- API key لگائے اور سرور deploy کیے بغیر ایپ حقیقی AI جواب نہیں دے سکتی۔

## Gemini متبادل

اگر Gemini استعمال کرنا ہو تو Render میں `AI_PROVIDER=gemini`، `GEMINI_API_KEY` اور اختیاری `GEMINI_MODEL=gemini-2.5-flash` مقرر کریں۔

## APK بنانے کا طریقہ

اس پروجیکٹ میں GitHub Actions workflow شامل ہے جو Android APK بناتا ہے۔ Workflow چلانے کے لیے repository میں سورس اپ لوڈ ہونا اور `API_BASE_URL` variable مقرر ہونا ضروری ہے۔
