# Sindhi AI Learning Assistant — v1.7.1

Flutter Android app for learning Sindhi in Sindhi, Urdu, Roman Sindhi and English. The project includes an AI Tutor screen and a secure Node.js backend for Google OpenAI.

**اردو میں مکمل سیٹ اپ:** `START_HERE_UR.md` پڑھیں۔

## Features
- Home, AI Tutor, Learn and Culture tabs.
- Sindhi alphabet, vocabulary, grammar lessons, quiz and culture pages.
- Chat UI supports Sindhi, Roman Sindhi, Urdu and English.
- Optional live OpenAI responses through the included Node.js backend.
- API key remains server-side; never embedded in the Android app.
- GitHub Actions workflow builds a release APK.

## Important
The ZIP is source code, not a compiled APK. A real AI reply requires deploying `server/` and setting `OPENAI_API_KEY` on the server. Then set GitHub Actions variable `API_BASE_URL` to the deployed server base URL and run **Build Android APK**. See `START_HERE_UR.md` for exact steps.

## Local build
Requires Flutter stable and Android SDK:
```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR-SERVER-DOMAIN
```
APK output: `build/app/outputs/flutter-apk/app-release.apk`.


For OpenAI setup, see [START_HERE_UR.md](START_HERE_UR.md). The backend uses the OpenAI Responses API by default; keep `OPENAI_API_KEY` on the server only.
